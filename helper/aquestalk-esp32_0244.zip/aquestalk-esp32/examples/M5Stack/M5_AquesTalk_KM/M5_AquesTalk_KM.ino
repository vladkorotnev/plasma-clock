// M5_AquesTalk_KM.ino - AquesTalk ESP32 サンプルプログラム
//	M5Stack用 漢字テキストからの音声合成
//  ・ボタン操作で音声出力/停止
//  ・シリアルモニタから任意の漢字テキスト(UTF8/CR)を送信して音声合成出力
//  ・辞書データファイルはSDカードに保存しておく。

#include <M5UnitLCD.h>
#include <M5UnitOLED.h>
#include <M5Unified.h>
#include "AquesTalkTTS.h" // AquesTalk-ESP32のラッパークラス

void setup(void)
{
  Serial.begin(115200);

  auto cfg = M5.config();
  // 使用するスピーカーに true を設定する
//cfg.external_speaker.module_display = true;
//cfg.external_speaker.module_rca     = true;
//cfg.external_speaker.hat_spk        = true;
//cfg.external_speaker.hat_spk2       = true;
  cfg.external_speaker.atomic_spk     = true;

  M5.begin(cfg);	// M5UnifiedはSD.begin()しない

	// AquesTalkの初期化
  if (int iret = TTS.createK()) { // 漢字テキスト使用
    if(iret==501){
      Serial.print("ERR:SD card not found");
      M5.Display.println("ERR:SD card not found");
    }else {
      Serial.print("ERR:TTS.createK()");
      M5.Display.println("ERR:TTS.createK()");
    }
    return;
  }
  
  M5.Speaker.setVolume(128);


  M5.Display.println("AquesTalk-KM (KANJI) demo");
  M5.Display.println("");
  M5.Display.println("BtnA: sample message");
  M5.Display.println("BtnB: day 1-31");
  M5.Display.println("BtnC: stop");
  M5.Display.println("");
  M5.Display.println("Try sending any Kanji text(UTF8/CR) from serial port");

  TTS.playK("AquesTalk-KMのサンプルプログラムです。");
}

void loop(void)
{
  M5.update();
	static bool bCountup=false;
	static int  mday=1;

  if (Serial.available()) {
    int iret;
    char kstr[256];
    size_t len = Serial.readBytesUntil('\r', kstr, 256);
    kstr[len]=0;

    if(kstr[0]=='#'){ // 先頭が'#'の場合、音声記号列入力
      iret = TTS.play(kstr+1, 100); 
    } else {
      iret = TTS.playK(kstr, 100);
    }
    if(iret){
      M5.Lcd.print("ERR:TTS.playK()=");
      M5.Lcd.println(iret);
    }
	}
	
	if(M5.BtnA.wasPressed()){
    unsigned long ms0 = millis();
    TTS.playK("新しいライブラリは、漢字テキストから音声合成ができるようになりました。", 100);
    unsigned long ms = millis() - ms0;
    M5.Lcd.printf("%ld ms\n", ms);
	}
	else if(M5.BtnB.wasPressed()){
    bCountup = true;
	}
	else if(M5.BtnC.wasPressed()){
		TTS.stop();
    bCountup = false;
	}

	if(bCountup){
		if(TTS.isPlay()==false){
			char koe[64];
			sprintf(koe, "<NUMK VAL=%d COUNTER=nichi>.",mday);
			TTS.play(koe, 100);
			mday++;
			if(mday>31) mday=1;
		}
	}
}

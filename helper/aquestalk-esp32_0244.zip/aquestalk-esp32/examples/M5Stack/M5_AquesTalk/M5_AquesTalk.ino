// M5_AquesTalk.ino - AquesTalk ESP32 サンプルプログラム
//	M5Stack用 音声記号列からの音声合成
//  ・ボタン操作で音声出力

#include <M5UnitLCD.h>
#include <M5UnitOLED.h>
#include <M5Unified.h>
#include "AquesTalkTTS.h" // AquesTalk-ESP32のラッパークラス

void setup(void)
{
  auto cfg = M5.config();

  // 試用するスピーカーに true を設定する
//cfg.external_speaker.module_display = true;
//cfg.external_speaker.module_rca     = true;
//cfg.external_speaker.hat_spk        = true;
//cfg.external_speaker.hat_spk2       = true;
  cfg.external_speaker.atomic_spk     = true;

  M5.begin(cfg);

 	// AquesTalkの初期化
  if (TTS.create()) {
    M5.Display.println("ERR:TTS.create()");
  }
  M5.Speaker.setVolume(128);

  TTS.play("akue_suto'-_ku/kido-shima'_shita.");
  TTS.wait();   // 終了まで待つ
  TTS.play("botanno/o_shitekudasa'i.");
  M5.Display.println("Push any button!");
}

void loop(void)
{
  M5.update();

  if (     M5.BtnA.wasClicked())  { TTS.play("kuri'kku"); }
  else if (M5.BtnA.wasHold())     { TTS.play("ho'-rudo"); }
  else if (M5.BtnA.wasReleased()) { TTS.play("riri'-su"); }
  else if (M5.BtnB.wasReleased()) { TTS.play("korewa;te'_sutode_su."); }
  else if (M5.BtnC.wasReleased()) { TTS.play("yukkuri_siteittene?"); }
}

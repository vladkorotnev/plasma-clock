// hello_aquestalk_km_i2s.ino - AquesTalk ESP32 サンプルプログラム
//  ・シリアルモニタから任意の漢字テキスト(UTF8/CR)を送信して音声合成出力
//  ・音声データはI2S出力。外付けのI2SアンプやI2S DAコンバーターが別途必要。
//  ・辞書データファイルはSPIで接続したSDカードに保存しておく。

#include "AquesTalkTTS.h" // AquesTalk-ESP32のラッパークラス

void setup() {
	int iret;
	Serial.begin(115200);

 	// AquesTalkの初期化
  if (TTS.createK()) {
    Serial.println("ERR:TTS.createK()");
  }
  else {
    Serial.println("OK:TTS.createK()");
  }
  TTS.setVolume(128); // 音量設定 0-255(max,default)

  TTS.playK("漢字テキストからの音声合成です。");
  Serial.println("Try sending any Kanji text(UTF8/CR) from serial port");
}
  

void loop() {
    if (Serial.available()) {
    int iret;
    char kstr[256];
    size_t len = Serial.readBytesUntil('\r', kstr, 256);
    kstr[len]=0;

    if(kstr[0]=='#'){ // 先頭が'#'の場合、音声記号列入力とする
      iret = TTS.play(kstr+1, 100); 
    } else {
      iret = TTS.playK(kstr, 100);
    }
    if(iret){
      Serial.print("ERR:TTS.playK()=");
      Serial.println(iret);
    }
	}
  delay(1);
}
